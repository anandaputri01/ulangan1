<?php

$host = "localhost";
$user = "root";
$pass = "";
$db	  = "php_crud";

$dbconnect = new mysqli ("$host","$user","$pass","$db");

if (!$conn) {
	
	die("<script>alert('anda berhasil terhubung')</script>");
}
echo("<script>alert('anda gagal terhubung')</script>")

?>