<?php

include 'koneksi.php';

$nama= $_POST['nama'];
$email= $_POST['email'];
$notelepon= $_POST['notelepon'];
$pekerjaan= $_POST['pekerjaan'];



 mysqli_query($dbconnect, "INSERT INTO kontak VALUES ( NULL, '$nama','$email','$notelepon','$pekerjaan')");

 header("location:user.php")
 ?>